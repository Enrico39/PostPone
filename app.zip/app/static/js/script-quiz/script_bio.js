
/* --- JAVASCRIPT FOR QUESTIONS AND ANSWERS IN TRIVIA QUIZ --- */

/* The const declaration creates block-scoped constants.
 The value of a constant can't be changed through reassignment (i.e. by using the assignment operator)
  and it can't be redeclared (i.e. through a variable declaration).
   However, if a constant is an object or array its properties or items can be updated or removed.
    */

//set of questions and answers for the category "biology"
const quizData = [
    {

        question: "Quale dei seguenti fattori può influire sull'attività di un enzima?", // question
      // possible answers
        a: "Variazioni di pH",
        b: "Variazioni di temperatura",
        c: "Effetti allosterici",
        d: "Tutti i fattori su elencati",
        correct: "d", //correct answer
    },
    {
        question: "In una soluzione con pH 2 saranno attivi enzimi:", // question
      // possible answers
      a: "Lisosomali",
        b: "Del Golgi",
        c: "Digestivi, prodotti nello stomaco, come ad esempio la pepsina",
        d: "Dei perossisomi",
        correct: "c",  //correct answer
    },
    {
        question: "Riguardo all'ATP è falso che: ", // question
      // possible answers
      a: "E' sintetizzata durante reazioni esoergoniche",
        b: "E' idrolizzata durante reazioni endoergoniche",
        c: "La sua idrolisi accelera le reazioni biochimiche",
        d: "Può essere consumata durante reazioni anaboliche",
        correct: "c",  //correct answer
    },
    {
        question: "Le proteine multipasso della membrana plasmatica:", // question
      // possible answers
      a: "Nessuna di queste risposte è corretta",
        b: "Hanno una sequenza aminoacidica che contiene sequenze segnale di indirizzamento verso il\n" +
          "RE seguite da sequenze idrofobiche di arresto di trasferimento verso il RE",
        c: "Hanno una sequenza aminoacidica che contiene solo sequenze idrofobiche di arresto, senza\n" +
          "sequenze segnale di indirizzamento verso il RE",
        d: "Sia b che c sono corrette",
        correct: "b",  //correct answer
    },
];

const quiz = document.getElementById('quiz')
const answerEls = document.querySelectorAll('.answer')
const questionEl = document.getElementById('question')
const a_text = document.getElementById('a_text')
const b_text = document.getElementById('b_text')
const c_text = document.getElementById('c_text')
const d_text = document.getElementById('d_text')
const submitBtn = document.getElementById('submit')

let currentQuiz = 0 //declaration for the current quiz
let score = 0 //declaration for the score

//function call of loadQuiz
loadQuiz()

function loadQuiz() { //creation of the function for loading the quiz
    deselectAnswers() //function call for deselecting a previously selected answer

    const currentQuizData = quizData[currentQuiz] // I assign to currentQuizData the index element currentQuiz of QuizData

    questionEl.innerText = currentQuizData.question //current quiz
    a_text.innerText = currentQuizData.a //first possible answer
    b_text.innerText = currentQuizData.b //second possible answer
    c_text.innerText = currentQuizData.c //third possible answer
    d_text.innerText = currentQuizData.d //fourth possible answer
}
//creation of the function for deselecting a previously selected answer
function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false)
}
//creation of the function for selecting one of the answers
function getSelected() {
    let answer
//check of selected answer
    answerEls.forEach(answerEl => {
      //if a certain answer is selected then this is taken as the user's chosen answer for the current quiz
        if(answerEl.checked) {
            answer = answerEl.id
        }
    })

    return answer
}

submitBtn.addEventListener('click', () => { //confirmation of the answer
    const answer = getSelected() //I assign the answer selection to "answer"

  //if the chosen answer is equal to the correct answer of the current quiz then the score increases by 1
    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++
        }

        currentQuiz++ //move on to the next quiz

      //if the index of the current quiz is now less than the number of quizzes present for this category then load the following quiz
        if(currentQuiz < quizData.length) {
            loadQuiz()
        } else {
          //otherwise if the score is n out of n then it displays "you answered n questions correctly"
            if(score==4) {
                quiz.innerHTML = `
                <h2>Hai risposto a ${score}/${quizData.length} domande correttamente</h2>
                `
              //In this case, the button for the obtaining the medal appears
                document.getElementById("getmedal").style.display="initial";
            }else
              //otherwise, if you haven't answered all the questions correctly, then the number of correct answers given will simply appear.
                { quiz.innerHTML = `
                <h2>Hai risposto a ${score}/${quizData.length} domande correttamente</h2>
                 <!-- button to retry the whole quiz again -->
                <button onclick="location.reload()">Riprova</button>


            `}
        }


    }
})
