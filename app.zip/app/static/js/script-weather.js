const timeEl = document.getElementById('time'); //current time
const dateEl = document.getElementById('date'); //current date
const currentWeatherItemsEl = document.getElementById('current-weather-items'); //weather information for the current day
const timezone = document.getElementById('time-zone'); // time-zone for the location of the user
const countryEl = document.getElementById('country'); // country location of the user
const weatherForecastEl = document.getElementById('weather-forecast'); //weather forecast information
const currentTempEl = document.getElementById('current-temp'); // other days weather information

//DAYS IN A WEEK
const days = ['Domenica', 'Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato'];
//MONTHS IN A YEAR
const months = ['Gen', 'Feb', 'Mar', 'Apr', 'MaG', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'];

//API FOR WEATHER FORECAST INFORMATION
const API_KEY ='49cc8c821cd2aff9af04c9f98c36eb74';

//INFORMATION ABOUT TIME AND DATE FOR THE CURRENT DAY
setInterval(() => {
  const time = new Date();
  const month = time.getMonth(); //MONTH
  const date = time.getDate(); //DAY
  const day = time.getDay(); //DAY NUMBER
  const hour = time.getHours(); //HOUR
  const hoursIn12HrFormat = hour >= 13 ? hour %12: hour
  const minutes = time.getMinutes(); //MINUTES
  const ampm = hour >=12 ? 'PM' : 'AM'

  timeEl.innerHTML = (hour < 10? '0'+hour : hour) + ':' + (minutes < 10? '0'+minutes: minutes) //HOUR + MINUTES
  dateEl.innerHTML = days[day] + ', ' + date+ ' ' + months[month] //DAY + DATE + MONTH

}, 1000); //TIMEOUT INTERVAL FOR DATE-TIME INFORMATION




//CALL TO GETWEATHERDATA FUNCTION
getWeatherData()

//Function for getting weather info
function getWeatherData () {
  navigator.geolocation.getCurrentPosition((success) => { //geolocation request

    let {latitude, longitude } = success.coords; //get information about latitude and longitude
//search weather info on openweathermap
    fetch(`https://api.openweathermap.org/data/2.5/onecall?lat=${latitude}&lon=${longitude}&exclude=hourly,minutely&units=metric&appid=${API_KEY}&lang={it}`).then(res => res.json()).then(data => {
      //when the weather info has been fetched then it is shown to the user
      console.log(data)
      showWeatherData(data);
    })

  })
}

function showWeatherData (data){
  //Show the following info for the current day
  let {humidity, pressure, sunrise, sunset, wind_speed} = data.current;

//Umidity, Pressure, Wind Speed, Sunrise, Sunset INFO
  currentWeatherItemsEl.innerHTML =
    `<div class="weather-item">
        <div>Umidità</div>
        <div>${humidity}%</div>
    </div>
    <div class="weather-item">
        <div>Pressione</div>
        <div>${pressure}</div>
    </div>
    <div class="weather-item">
        <div>Velocità del vento&nbsp&nbsp</div>
        <div>${wind_speed}</div>
    </div>

    <div class="weather-item">
        <div>Alba</div>
        <div>${window.moment(sunrise * 1000).format('HH:mm ')}</div>
    </div>
    <div class="weather-item">
        <div>Tramonto&nbsp&nbsp&nbsp&nbsp&nbsp</div>
        <div>${window.moment(sunset*1000).format('HH:mm ')}</div>
    </div>


    `;


  //OTHER DAYS INFO
  let otherDayForcast = ''
  data.daily.forEach((day, idx) => { //FOR EACH DAY OF THE WEEK
    if(idx == 0){ //if the index refers to current day
      //Searching images for current day on openweathermap
      currentTempEl.innerHTML = `
            <img src="http://openweathermap.org/img/wn//${day.weather[0].icon}@4x.png" alt="weather icon" class="w-icon"> <!-- image related to weather conditions -->
            <div class="other">
                <div class="day">${window.moment(day.dt*1000).format('dddd')}</div> <!-- SHOW THE NAME OF THE DAY -->
                <div class="temp">Notte - ${day.temp.night}&#176;C</div> <!-- temperature during the night -->
                <div class="temp">Giorno - ${day.temp.day}&#176;C</div> <!-- temperature during the day -->
            </div>

            `
    }else{ // else the index refers to other days then do the same but for the other days
      otherDayForcast += `
            <div class="weather-forecast-item">
                <div class="day">${window.moment(day.dt*1000).format('ddd')}</div>
                <img src="http://openweathermap.org/img/wn/${day.weather[0].icon}@2x.png" alt="weather icon" class="w-icon">
                <div class="temp">Notte - ${day.temp.night}&#176;C</div>
                <div class="temp">Giorno - ${day.temp.day}&#176;C</div>
            </div>

            `
    }
  })

//assign otherDayForecast to weatherForecastEl
  weatherForecastEl.innerHTML = otherDayForcast;
}
