/*
The Document method querySelector() returns the first Element within the document that matches the specified selector, or group of selectors. If no matches are found, null is returned.
 */

//SIGN IN BUTTTON
const sign_in_btn = document.querySelector("#sign-in-btn");
//SIGN UP BUTTON
const sign_up_btn = document.querySelector("#sign-up-btn");
//CONTAINER
const container = document.querySelector(".container");

/*
The addEventListener() method attaches an event handler to the specified element.

The addEventListener() method attaches an event handler to an element without overwriting existing event handlers.
 */

//Event listener for sign up
sign_up_btn.addEventListener("click", () => {
  //The Element.classList is a read-only property that returns a live DOMTokenList collection of the class attributes of the element. This can then be used to manipulate the class list.
  // Using classList is a convenient alternative to accessing an element's list of classes as a space-delimited string via element.className.
  container.classList.add("sign-up-mode");
});

//Event listener for sign in
sign_in_btn.addEventListener("click", () => {
  //The Element.classList is a read-only property that returns a live DOMTokenList collection of the class attributes of the element. This can then be used to manipulate the class list.
  // Using classList is a convenient alternative to accessing an element's list of classes as a space-delimited string via element.className.
  container.classList.remove("sign-up-mode");
});
