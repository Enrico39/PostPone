
const quizData = [
    {

        question: "La nascita della Sociologia è favorita da:",
        a: "Due Rivoluzioni",
        b: "Quattro Rivoluzioni",
        c: "Tre Rivoluzioni",
        d: "Una rivoluzione",
        correct: "c",
    },
    {
        question: "La sociologia è: ",
        a: "La scienza sociale che si occupa delle forme e dei processi della vita umana associata",
        b: "La scienza sociale che si occupa dell'evoluzione della vita umana ",
        c: "La scienza sociale che si occupa dello sviluppo delle comunità ",
        d: "La scienza sociale che prende le distanze dalla filosofia ",
        correct: "a",
    },
    {
        question: "Ad Auguste Comte si deve: ",
        a: "Aver reso autonoma la sociologia",
        b: "Aver coniato il termine \"sociologia\" ",
        c: "Aver promosso la sociologia tra i filosofi",
        d: "Aver distinto la sociologia dalla filosofia",
        correct: "b",
    },
    {
        question: "La visione sociologica si basa sulle capacità di:",
        a: "Liberarsi e/o essere consapevole dei condizionamenti delle abitudini conoscitive del proprio ambiente socio-culturale. ",
        b: "Saper prevedere cosa accadrà nelle generazioni future ",
        c: "Saper osservare i comportamenti del genere umano ",
        d: "Saper distinguere ciò che favorisce l'evoluzione sociale, da ciò che invece la cristallizza ",
        correct: "a",
    },
];

const quiz = document.getElementById('quiz')
const answerEls = document.querySelectorAll('.answer')
const questionEl = document.getElementById('question')
const a_text = document.getElementById('a_text')
const b_text = document.getElementById('b_text')
const c_text = document.getElementById('c_text')
const d_text = document.getElementById('d_text')
const submitBtn = document.getElementById('submit')

let currentQuiz = 0
let score = 0

loadQuiz()

function loadQuiz() {
    deselectAnswers()

    const currentQuizData = quizData[currentQuiz]

    questionEl.innerText = currentQuizData.question
    a_text.innerText = currentQuizData.a
    b_text.innerText = currentQuizData.b
    c_text.innerText = currentQuizData.c
    d_text.innerText = currentQuizData.d
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false)
}

function getSelected() {
    let answer

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id
        }
    })

    return answer
}

submitBtn.addEventListener('click', () => {
    const answer = getSelected()

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++
        }

        currentQuiz++

        if(currentQuiz < quizData.length) {
            loadQuiz()
        } else {
            if(score==4) {
                quiz.innerHTML = `
                <h2>Hai risposto a ${score}/${quizData.length} domande correttamente</h2>
                `
                document.getElementById("getmedal").style.display="initial";
            }else { quiz.innerHTML = `
                <h2>Hai risposto a ${score}/${quizData.length} domande correttamente</h2>

                <button onclick="location.reload()">Riprova</button>
                
                
            `}
        }


    }
})
