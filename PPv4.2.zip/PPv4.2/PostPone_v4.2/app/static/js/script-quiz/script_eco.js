const quizData = [
    {

        question: "La persona giuridica:",
        a: "E' un soggetto di diritto, costituito da tante persone giuridiche e beni che si uniscono per raggiungere fini comuni",
        b: "E' un soggetto di fatto, costituito da persone fisiche e beni che si uniscono per raggiungere fini comuni",
        c: "E' un soggetto di fatto, costituito da tante persone giuridiche e beni che si uniscono per raggiungere fini comuni",
        d: "E' un soggetto di diritto, costituito da persone fisiche e beni che si uniscono per raggiungere fini comuni",
        correct: "d",
    },
    {
        question: "Il codice civile disciplina il concetto di imprenditore all'articolo:",
        a: "2024",
        b: "2425 ter",
        c: "2082",
        d: "2425",
        correct: "c",
    },
    {
        question: "Sotto il profilo giuridico l'attività di impresa è: ",
        a: "Tutte le alternative sono corrette",
        b: "Finalizzata allo scambio di servizi",
        c: "Finalizzata alla produzione di scambi di beni",
        d: "Un'attività economica professionalmente organizzata dall'imprenditore",
        correct: "a",
    },
    {
        question: "L'equilibrio finanziario si raggiunge quando:",
        a: "Le entrate sono maggiori o uguali alle uscite",
        b: "I ricavi sono minori delle uscite",
        c: "I ricavi sono uguali ai costi",
        d: "I costi sono uguali alle uscite",
        correct: "a",
    },
];


const quiz = document.getElementById('quiz')
const answerEls = document.querySelectorAll('.answer')
const questionEl = document.getElementById('question')
const a_text = document.getElementById('a_text')
const b_text = document.getElementById('b_text')
const c_text = document.getElementById('c_text')
const d_text = document.getElementById('d_text')
const submitBtn = document.getElementById('submit')

let currentQuiz = 0
let score = 0

loadQuiz()

function loadQuiz() {
    deselectAnswers()

    const currentQuizData = quizData[currentQuiz]

    questionEl.innerText = currentQuizData.question
    a_text.innerText = currentQuizData.a
    b_text.innerText = currentQuizData.b
    c_text.innerText = currentQuizData.c
    d_text.innerText = currentQuizData.d
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false)
}

function getSelected() {
    let answer

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id
        }
    })

    return answer
}

submitBtn.addEventListener('click', () => {
    const answer = getSelected()

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++
        }

        currentQuiz++

        if(currentQuiz < quizData.length) {
            loadQuiz()
        } else {
            quiz.innerHTML = `
                <h2>Hai risposto a ${score}/${quizData.length} domande correttamente</h2>

                <button onclick="location.reload()">Riprova</button>
            `
        }
    }
})
