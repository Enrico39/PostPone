const checkIfUserExists = () => {
    const registrationForm = document.forms['registration-form']
    const emailFormElement = registrationForm['email-address']
    const email = emailFormElement.value
    axios.post('/validate-user', {
        email: email
    })
        .then((response) => {
            if(response.data.user_exists == "true") {
                /*Swal.fire({     //ITERAZIONE UOMO-MACCHINA: segnalare questo tipo di problemi tamite una scritta vicino al form è meglio che aprire un'altra finestra
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Esiste già un account con questa mail associata. Per favore cambia indirizzo.',
                   })*/

                emailFormElement.setCustomValidity('Esiste già un account con questa mail associata. Per favore cambia indirizzo.')
                emailFormElement.reportValidity()
                //emailFormElement.value=""
            }

        }, (error) => {
            console.log(error)
        })
}

const checkIfUserExistsWithEvent = (e) => {
    emailFormElement = e.target
    email = e.target.value
    console.log(email)
    axios.post('/validate-user', {
        email: email
    })
        .then((response) => {
            if(response.data.user_exists == "true") {
                emailFormElement.setCustomValidity('This user already exists, please login instead.')
                emailFormElement.reportValidity()

            }

        }, (error) => {

            console.log(error)

        })


}
