const timeEl = document.getElementById('time');
const dateEl = document.getElementById('date');
const currentWeatherItemsEl = document.getElementById('current-weather-items');
const timezone = document.getElementById('time-zone');
const countryEl = document.getElementById('country');
const weatherForecastEl = document.getElementById('weather-forecast');
const currentTempEl = document.getElementById('current-temp');


const days = ['Domenica', 'Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato'];
const months = ['Gen', 'Feb', 'Mar', 'Apr', 'MaG', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'];

const API_KEY ='49cc8c821cd2aff9af04c9f98c36eb74';

setInterval(() => {
  const time = new Date();
  const month = time.getMonth();
  const date = time.getDate();
  const day = time.getDay();
  const hour = time.getHours();
  const hoursIn12HrFormat = hour >= 13 ? hour %12: hour
  const minutes = time.getMinutes();
  const ampm = hour >=12 ? 'PM' : 'AM'

  //timeEl.innerHTML = (hoursIn12HrFormat < 10? '0'+hoursIn12HrFormat : hoursIn12HrFormat) + ':' + (minutes < 10? '0'+minutes: minutes)+ ' ' + `<span id="am-pm">${ampm}</span>`
  timeEl.innerHTML = (hour < 10? '0'+hour : hour) + ':' + (minutes < 10? '0'+minutes: minutes)
  dateEl.innerHTML = days[day] + ', ' + date+ ' ' + months[month]

}, 1000);

getWeatherData()
function getWeatherData () {
  navigator.geolocation.getCurrentPosition((success) => {

    let {latitude, longitude } = success.coords;

    fetch(`https://api.openweathermap.org/data/2.5/onecall?lat=${latitude}&lon=${longitude}&exclude=hourly,minutely&units=metric&appid=${API_KEY}&lang={it}`).then(res => res.json()).then(data => {

      console.log(data)
      showWeatherData(data);
    })

  })
}

function showWeatherData (data){
  let {humidity, pressure, sunrise, sunset, wind_speed} = data.current;


  currentWeatherItemsEl.innerHTML =
    `<div class="weather-item">
        <div>Umidità</div>
        <div>${humidity}%</div>
    </div>
    <div class="weather-item">
        <div>Pressione</div>
        <div>${pressure}</div>
    </div>
    <div class="weather-item">
        <div>Velocità del vento&nbsp&nbsp</div>
        <div>${wind_speed}</div>
    </div>

    <div class="weather-item">
        <div>Alba</div>
        <div>${window.moment(sunrise * 1000).format('HH:mm ')}</div>
    </div>
    <div class="weather-item">
        <div>Tramonto&nbsp&nbsp&nbsp&nbsp&nbsp</div>
        <div>${window.moment(sunset*1000).format('HH:mm ')}</div>
    </div>


    `;

  let otherDayForcast = ''
  data.daily.forEach((day, idx) => {
    if(idx == 0){
      currentTempEl.innerHTML = `
            <img src="http://openweathermap.org/img/wn//${day.weather[0].icon}@4x.png" alt="weather icon" class="w-icon">
            <div class="other">
                <div class="day">${window.moment(day.dt*1000).format('dddd')}</div>
                <div class="temp">Notte - ${day.temp.night}&#176;C</div>
                <div class="temp">Giorno - ${day.temp.day}&#176;C</div>
            </div>

            `
    }else{
      otherDayForcast += `
            <div class="weather-forecast-item">
                <div class="day">${window.moment(day.dt*1000).format('ddd')}</div>
                <img src="http://openweathermap.org/img/wn/${day.weather[0].icon}@2x.png" alt="weather icon" class="w-icon">
                <div class="temp">Notte - ${day.temp.night}&#176;C</div>
                <div class="temp">Giorno - ${day.temp.day}&#176;C</div>
            </div>

            `
    }
  })


  weatherForecastEl.innerHTML = otherDayForcast;
}
