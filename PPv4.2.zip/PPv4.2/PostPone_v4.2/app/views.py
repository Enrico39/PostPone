from werkzeug.utils import redirect
from app import app, db
from app.models import User, PostPone
from flask import json, render_template, request, session, url_for, jsonify, flash
from datetime import date

import os
msg=''
@app.route('/')
def index():
    if 'user' in session.keys():
        return redirect(url_for('home'))
    else:
        return render_template('main.html')



@app.route('/home')
def home():
    if 'user' in session.keys():
        user_id = None
        if session['user']:
            user_id=session['user']
            utente = User.query.filter_by(id=user_id)
            today=date.today()
            number=PostPone.query.filter_by(fkey=user_id).filter(PostPone.date == today).count()
            if number==0:
               msg='non hai postpone oggi'
               return render_template('home.html',utente=utente,msg=msg)
            else:
               msg=' i postpone di oggi ;'
               pp = PostPone.query.filter_by(fkey=user_id).filter(PostPone.date == today)
               return render_template('home.html',utente=utente,pp=pp,msg=msg)
    else:
        return render_template('main.html')


@app.route('/ricompense', methods=['GET', 'POST'])
def ricompense():
    user_id = None
    if session['user']:
            user_id=session['user']
            utente = User.query.filter_by(id=user_id)
            return render_template('ricompense.html',utente=utente)

@app.route('/chisiamo', methods=['GET', 'POST'])
def chisiamo():
    return render_template('chisiamo.html')

@app.route('/profilo', methods=['GET', 'POST'])
def profilo():
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id)
        return render_template('mioprofilo.html',utente=utente,msg=msg)

@app.route('/pomodoroclock', methods=['GET', 'POST'])
def pomodoroclock():
    return render_template('pomodoroclock.html')

@app.route('/triviaquiz', methods=['GET', 'POST'])
def triviaquiz():
    return render_template('quizindex.html')

@app.route('/register-user', methods=['POST'])
def register_user():
    form = request.form
    user = User(
        username=form['username'],
        name=form['name'],
        surname=form['surname'],
        email=form['email-address'],
        medaglie=0,
        postpone_completati=0,
        coupon_ottenuti=0)
    user.set_password(form['password'])
    db.session.add(user)
    db.session.commit()
    return redirect(url_for('index'))

@app.route('/validate-user', methods=['POST'])
def validate_user():
    if request.method == "POST":
        email_address = request.get_json()['email']
        user = User.query.filter_by(email=email_address).first()
        if user:
            return jsonify({'user_exists': 'true'})
        else:
            return jsonify({'user_exists': 'false'})

@app.route('/validate-password', methods=['POST'])
def validate_password():
    if request.method == "POST":
        email_address = request.get_json()['email']
        password = request.get_json()['password']
        userFound = 'false'
        passwordCorrect = 'false'
        user = User.query.filter_by(email=email_address).first()
        if user:
            userFound = 'true'
            if user.check_password(password):
                passwordCorrect = 'true'

        return jsonify({'user_exists': userFound, 'passwordCorrect': passwordCorrect})

@app.route('/login-user', methods=['POST'])
def login_user():
    msg=""
    form = request.form
    user = User.query.filter_by(email=form['email-address']).first()

    if not user:
        msg = "email non trovata nel sistema, registrati!"
        return render_template('main.html', form=form,msg=msg)

    if user and user.check_password(form['password']):
        session['user'] = user.id
        return redirect(url_for('home'))
    else:

        msg = "Username o password sbagliati, riprova!"
        return render_template('main.html', form=form,msg=msg)




@app.route('/logout-user', methods=['POST', 'GET'])
def logout_user():
    session.pop('user', None)
    return redirect(url_for('index'))



@app.route('/info', methods=['GET', 'POST'])
def info():
    return render_template('templates_quiz/quizinformatica.html')


@app.route('/bio', methods=['GET', 'POST'])
def bio():
    return render_template('templates_quiz/index_bio.html')




@app.route('/nav', methods=['GET', 'POST'])
def nav():
    return render_template('templates_quiz/index_nav.html')

@app.route('/eco', methods=['GET', 'POST'])
def eco():
    return render_template('templates_quiz/index_eco.html')


@app.route('/giu', methods=['GET', 'POST'])
def giu():
    return render_template('templates_quiz/index_giur.html')


@app.route('/tel', methods=['GET', 'POST'])
def tel():
    return render_template('templates_quiz/index_telec.html')


@app.route('/soc', methods=['GET', 'POST'])
def soc():
    return render_template('templates_quiz/index_sociol.html')


@app.route('/ing', methods=['GET', 'POST'])
def ing():
    return render_template('templates_quiz/index_ing_gest.html')


@app.route('/reti', methods=['GET', 'POST'])
def reti():
    return render_template('templates_quiz/index_reti.html')

@app.route('/ingsw', methods=['GET', 'POST'])
def ingsw():
    return render_template('templates_quiz/index_ing_soft.html')

@app.route('/prog3', methods=['GET', 'POST'])
def prog3():
    return render_template('templates_quiz/index_prog3.html')

@app.route('/so', methods=['GET', 'POST'])
def so():
    return render_template('templates_quiz/index_SO.html')

@app.route('/tw', methods=['GET', 'POST'])
def tw():
    return render_template('templates_quiz/index_tech_web.html')






@app.route('/change_uni', methods=['POST'])
def change_uni():
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        utente.uni=form['uni']


        db.session.commit()
        return redirect(url_for('profilo'))




@app.route('/change_cds', methods=['POST'])
def change_cds():
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        utente.cds=form['cds']


        db.session.commit()
        return redirect(url_for('profilo'))




@app.route('/change_cell', methods=['POST'])
def change_cell():
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        utente.cell=form['cell']

        db.session.commit()
        return redirect(url_for('profilo'))




@app.route('/change_eta', methods=['POST'])
def change_eta():
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        utente.eta=form['eta']

        db.session.commit()
        return redirect(url_for('profilo'))



@app.route('/change_password', methods=['POST'])
def change_password():
    msg=''
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        if utente.check_password(form['old_password']):
            if form['new_password']==form['confirm_password']:
                if form['new_password']=='':
                    msg='Compila i campi!'
                    utente = User.query.filter_by(id=user_id)
                    return render_template('mioprofilo.html',utente=utente,msg=msg)
                else:
                    utente.set_password(form['new_password'])
                    db.session.commit()
                    msg='Cambio password effettuato con successo!'
                    utente = User.query.filter_by(id=user_id)
                    return render_template('mioprofilo.html',utente=utente,msg=msg)
            else:
                msg='Password non corrispondenti'
                utente = User.query.filter_by(id=user_id)
                return render_template('mioprofilo.html',utente=utente,msg=msg)
        else:
            msg='Vecchia password errata'
            utente = User.query.filter_by(id=user_id)
            return render_template('mioprofilo.html',utente=utente,msg=msg)




@app.route('/delete_account', methods=['POST'])
def delete_account():
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        db.session.delete(utente)
        db.session.commit()
        msg='Account eliminato correttamente.'
        return render_template('main.html',msg=msg)




@app.route('/add_postpone', methods=['POST'])
def add_postpone():
    user_id = None
    form=request.form
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        postpone = PostPone(
            fkey=user_id,
            title=form['title'],
            description=form['description'],
            category=form['category'],
            date=form['date'])
        db.session.add(postpone)
        db.session.commit()
        return redirect(url_for('todo'))




@app.route('/todo', methods=['GET', 'POST'])
def todo():
    msg=''
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        number=PostPone.query.filter_by(fkey=user_id).count()
        if number==0:
            msg='Non ci sono PostPone.'
            return render_template('todo.html',utente=utente,msg=msg)
        else:
            pp = PostPone.query.filter_by(fkey=user_id).order_by(PostPone.date)
            return render_template('todo.html',utente=utente,pp=pp,msg=msg)



@app.before_first_request
def create_tables():
    db.create_all()


@app.route('/delete_postpone/<postpone_id>', methods=['GET','POST'])
def delete_postpone(postpone_id):
        PostPone.query.filter_by(id=postpone_id).delete()
        db.session.commit()
        return redirect(url_for('todo'))




@app.route('/delete_postpone_home/<postpone_id>', methods=['GET','POST'])
def delete_postpone_home(postpone_id):
        PostPone.query.filter_by(id=postpone_id).delete()
        db.session.commit()
        return redirect(url_for('home'))



@app.route('/complete_postpone/<postpone_id>', methods=['GET','POST'])
def complete_postpone(postpone_id):
        if session['user']:
                user_id=session['user']
                utente = User.query.filter_by(id=user_id).first()
                utente.medaglie=utente.medaglie+1
                utente.postpone_completati=utente.postpone_completati+1
                PostPone.query.filter_by(id=postpone_id).delete()
                db.session.commit()
        return redirect(url_for('todo'))





@app.route('/todo_order', methods=['GET', 'POST'])
def todo_order():
    msg=''
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        number=PostPone.query.filter_by(fkey=user_id).count()
        if number==0:
            msg='Non ci sono PostPone.'
            return render_template('todo.html',utente=utente,msg=msg)
        else:
            if form['order']=='Data':
                pp = PostPone.query.filter_by(fkey=user_id).order_by(PostPone.date)
                return render_template('todo.html',utente=utente,pp=pp,msg=msg)
            if form['order']=='Titolo':
                pp = PostPone.query.filter_by(fkey=user_id).order_by(PostPone.title)
                return render_template('todo.html',utente=utente,pp=pp,msg=msg)
            if form['order']=='Categoria':
                pp = PostPone.query.filter_by(fkey=user_id).order_by(PostPone.category)
                return render_template('todo.html',utente=utente,pp=pp,msg=msg)




@app.route('/todo_filter', methods=['GET', 'POST'])
def todo_filter():
             msg=''
             form=request.form
             user_id = None
             if session['user']:
                 user_id=session['user']
                 utente = User.query.filter_by(id=user_id).first()
                 number=PostPone.query.filter_by(fkey=user_id).count()
                 if number==0:
                     msg='Non ci sono PostPone.'
                     return render_template('todo.html',utente=utente,msg=msg)
                 else:
                     if form['filtro']=='Tutti':
                            return redirect(url_for('todo'))
                     if form['filtro']=='Studio':
                        number=PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Studio').count()
                        if number==0:
                             msg='Non ci sono PostPone relativi allo studio.'
                        pp = PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Studio')
                        return render_template('todo.html',utente=utente,pp=pp,msg=msg)
                     if form['filtro']=='Esame':
                        number=PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Esame').count()
                        if number==0:
                             msg='Non ci sono PostPone relativi ad esami.'
                        pp = PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Esame')
                        return render_template('todo.html',utente=utente,pp=pp,msg=msg)
                     if form['filtro']=='Ricevimento':
                        number=PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Ricevimento').count()
                        if number==0:
                             msg='Non ci sono PostPone relativi a ricevimenti.'
                        pp = PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Ricevimento')
                        return render_template('todo.html',utente=utente,pp=pp,msg=msg)
                     if form['filtro']=='Personale':
                        number=PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Personale').count()
                        if number==0:
                              msg='Non ci sono PostPone relativi ad impegni personali.'
                        pp = PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Personale')
                        return render_template('todo.html',utente=utente,pp=pp,msg=msg)
                     if form['filtro']=='Altro':
                        number=PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Altro').count()
                        if number==0:
                              msg='Non ci sono PostPone relativi ad altri impegni.'
                        pp = PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Altro')
                        return render_template('todo.html',utente=utente,pp=pp,msg=msg)