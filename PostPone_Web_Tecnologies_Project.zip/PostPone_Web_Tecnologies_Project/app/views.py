    #loading in memory a library of external functions (called modules ).
from werkzeug.utils import redirect
from app import app, db
from app.models import User, PostPone
from flask import json, render_template, request, session, url_for, jsonify, flash
from datetime import date
import os
import random
import string



    #declaring two external variables 
chars = string.ascii_letters + string.digits    #chars contains all the letters and numbers. It will be used to create coupon codes 
msg=''  #msg is useful to send messages in certain routes



    #creating all tables at first start
@app.before_first_request
def create_tables():
    db.create_all()



    #this is the '/' route
@app.route('/')
def index():
    if 'user' in session.keys():    #if the user is already logged-in, he will be redirected to the home 
        return redirect(url_for('home'))
    else:   #if the user is not logged-in, he will be redirected to the login/register page, named main.htmml
        return render_template('main.html')



@app.route('/home')
def home():
    if 'user' in session.keys():
        user_id = None
        if session['user']:
            #if the user is logged, python will search if the user has some PostPone due today.
            user_id=session['user']
            utente = User.query.filter_by(id=user_id)
            today=date.today()
            number=PostPone.query.filter_by(fkey=user_id).filter(PostPone.date == today).count() #the number of PostPone programmed for the courrent day is stored in 'number'
            if number==0:   #if the user has no PostPone to do, the system will show the msg
               msg='Non hai postpone programmati per oggi.'
               return render_template('home.html',utente=utente,msg=msg)
            else:    #if the user some PostPone to do, the system will show the msg and the PostPone
               msg='I tuoi PostPone di oggi:'
               pp = PostPone.query.filter_by(fkey=user_id).filter(PostPone.date == today)
               return render_template('home.html',utente=utente,pp=pp,msg=msg)
    else:   #if the user is not logged, he will be redirected to the main page
        return render_template('main.html')



    #this route redirects to the 'chi siamo' page
@app.route('/chisiamo', methods=['GET', 'POST'])
def chisiamo():
    return render_template('chisiamo.html')



    #this route redirects to the 'pomodoro clock' page
@app.route('/pomodoroclock', methods=['GET', 'POST'])
def pomodoroclock():
    return render_template('pomodoroclock.html')



    #this route is used to register a user
@app.route('/register-user', methods=['POST'])
def register_user():
    form = request.form #the variable 'form' has the values of the registration form filled by the user
    #these are the fields of a user
    user = User(
        username=form['username'],
        name=form['name'],
        surname=form['surname'],
        email=form['email-address'],
        medaglie=0,
        postpone_completati=0,
        coupon_ottenuti=0)
    user.set_password(form['password']) #setting the harshed password
    db.session.add(user)    #adding the user to database
    db.session.commit()     #committing changes
    return redirect(url_for('index'))   #redirect to index



    #this route is used to validate a user who is registering
@app.route('/validate-user', methods=['POST'])
def validate_user():
    if request.method == "POST":
        email_address = request.get_json()['email']     #this is the mail the user is giving to the system when he is trying to register
        user = User.query.filter_by(email=email_address).first()    #it checks if the user email is already in the system and it prevents to have 2 different users with the same email
        if user:
            return jsonify({'user_exists': 'true'})
        else:
            return jsonify({'user_exists': 'false'})



    #this route is used to login a user
@app.route('/login-user', methods=['POST'])
def login_user():
    msg=""
    form = request.form
    user = User.query.filter_by(email=form['email-address']).first()

    if not user:     #if the email is not in the db, the system will display the msg
        msg = "Email non trovata nel sistema, registrati!"
        return render_template('main.html', form=form,msg=msg)

    if user and user.check_password(form['password']):      #if the mail and password are correct, the user will be redirected to home
        session['user'] = user.id
        return redirect(url_for('home'))
    else:
        msg = "Email o password sbagliati, riprova!"    #if the password is not corresponding, the system will display the msg
        return render_template('main.html', form=form,msg=msg)



    #this route is used to logout a user
@app.route('/logout-user', methods=['POST', 'GET'])
def logout_user():
    session.pop('user', None)
    return redirect(url_for('index'))



    #this route redirects to the main 'quiz' page
@app.route('/triviaquiz', methods=['GET', 'POST'])
def triviaquiz():
    return render_template('quizindex.html')



    #these routes redirects to the various categories of 'quiz' page
@app.route('/info', methods=['GET', 'POST'])
def info():
    return render_template('templates_quiz/quizinformatica.html')

@app.route('/bio', methods=['GET', 'POST'])
def bio():
    return render_template('templates_quiz/index_bio.html')

@app.route('/nav', methods=['GET', 'POST'])
def nav():
    return render_template('templates_quiz/index_nav.html')

@app.route('/eco', methods=['GET', 'POST'])
def eco():
    return render_template('templates_quiz/index_eco.html')

@app.route('/giu', methods=['GET', 'POST'])
def giu():
    return render_template('templates_quiz/index_giur.html')

@app.route('/tel', methods=['GET', 'POST'])
def tel():
    return render_template('templates_quiz/index_telec.html')

@app.route('/soc', methods=['GET', 'POST'])
def soc():
    return render_template('templates_quiz/index_sociol.html')

@app.route('/ing', methods=['GET', 'POST'])
def ing():
    return render_template('templates_quiz/index_ing_gest.html')

@app.route('/reti', methods=['GET', 'POST'])
def reti():
    return render_template('templates_quiz/index_reti.html')

@app.route('/ingsw', methods=['GET', 'POST'])
def ingsw():
    return render_template('templates_quiz/index_ing_soft.html')

@app.route('/prog3', methods=['GET', 'POST'])
def prog3():
    return render_template('templates_quiz/index_prog3.html')

@app.route('/so', methods=['GET', 'POST'])
def so():
    return render_template('templates_quiz/index_SO.html')

@app.route('/tw', methods=['GET', 'POST'])
def tw():
    return render_template('templates_quiz/index_tech_web.html')


        #this route redirects to the main 'quiz' page, giving a user a medal as a reward if he completes a quiz
@app.route('/get_medal_quiz', methods=['GET','POST'])
def get_medal_quiz():
        if session['user']:
                user_id=session['user']
                utente = User.query.filter_by(id=user_id).first()
                utente.medaglie=utente.medaglie+1#adding medal
                db.session.commit()#db commit
        return redirect(url_for('triviaquiz'))


    #this route redirects to the 'profilo' page, if the user is logged
@app.route('/profilo', methods=['GET', 'POST'])
def profilo():
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id)
        return render_template('mioprofilo.html',utente=utente,msg=msg)



#this routes are used to change some user informations

@app.route('/change_uni', methods=['POST'])#change university
def change_uni():
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        utente.uni=form['uni'] #assignment of the new university
        db.session.commit() #db commit
        return redirect(url_for('profilo'))

@app.route('/change_cds', methods=['POST'])#change cds
def change_cds():
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        utente.cds=form['cds']   #assignment of the new cds
        db.session.commit() #db commit
        return redirect(url_for('profilo'))

@app.route('/change_cell', methods=['POST'])#change phone number
def change_cell():
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        utente.cell=form['cell'] #assignment of the new telephone number
        db.session.commit() #db commit
        return redirect(url_for('profilo'))

@app.route('/change_eta', methods=['POST'])#change age
def change_eta():
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        utente.eta=form['eta']   #assignment of the new age
        db.session.commit() #db commit
        return redirect(url_for('profilo'))

@app.route('/change_password', methods=['POST'])#change password
def change_password():
    msg=''
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        if utente.check_password(form['old_password']): #if the old password is correct
            if form['new_password']==form['confirm_password']: #if the new password and the confirm are the same
                if form['new_password']=='':    #if the new password is blank the system will sho a message
                    msg='Compila i campi!'
                    utente = User.query.filter_by(id=user_id)
                    return render_template('mioprofilo.html',utente=utente,msg=msg)
                else:
                    utente.set_password(form['new_password'])   #if it is everything ok, the password will be changed
                    db.session.commit() #db commit
                    msg='Cambio password effettuato con successo!'#msg of success
                    utente = User.query.filter_by(id=user_id)
                    return render_template('mioprofilo.html',utente=utente,msg=msg)
            else:   #if new password and confirmation password are not the same
                msg='Password non corrispondenti'   #error message
                utente = User.query.filter_by(id=user_id)
                return render_template('mioprofilo.html',utente=utente,msg=msg)
        else:#if the old password is not correct
            msg='Vecchia password errata' #error msg
            utente = User.query.filter_by(id=user_id)
            return render_template('mioprofilo.html',utente=utente,msg=msg)



    #this route is used to delete an user
@app.route('/delete_account', methods=['POST'])
def delete_account():
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first() #searching user
        db.session.delete(utente) #deleting user
        db.session.commit() #db commit
        msg='Account eliminato correttamente.' #confirm message
        return render_template('main.html',msg=msg)



    #this route is used to access the 'obiettivi' page
@app.route('/todo', methods=['GET', 'POST'])
def todo():
    msg=''
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        number=PostPone.query.filter_by(fkey=user_id).count()   #the system counts user's PostPone
        if number==0:   #if there aren't PostPone
            msg='Non ci sono PostPone.' #this message will be showed
            return render_template('todo.html',utente=utente,msg=msg)
        else:  #if there are PostPone
            pp = PostPone.query.filter_by(fkey=user_id).order_by(PostPone.date) #they will be showed
            return render_template('todo.html',utente=utente,pp=pp,msg=msg)



    #this route is used to add a PostPone
@app.route('/add_postpone', methods=['POST'])
def add_postpone():
    user_id = None
    form=request.form
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        #a postpone is composed by a foreign key, a title, a date, a description, a category and a date
        postpone = PostPone(
            fkey=user_id,
            title=form['title'],
            description=form['description'],
            category=form['category'],
            date=form['date'])
        db.session.add(postpone)    #adding postpone
        db.session.commit()     #db commit
        return redirect(url_for('todo'))



    #this route is used to delete a PostPone
@app.route('/delete_postpone/<postpone_id>', methods=['GET','POST'])
def delete_postpone(postpone_id):
        PostPone.query.filter_by(id=postpone_id).delete()   #search the postpone and deletes it
        db.session.commit()     #db commit
        return redirect(url_for('todo')) #redirects to todo route



    #this route is used to delete a PostPone from the homepage
@app.route('/delete_postpone_home/<postpone_id>', methods=['GET','POST'])
def delete_postpone_home(postpone_id):
        PostPone.query.filter_by(id=postpone_id).delete()     #search the postpone and deletes it
        db.session.commit()     #db commit
        return redirect(url_for('home'))    #redirects to home



    #this route is used to complete a PostPone from the homepage
@app.route('/complete_postpone_home/<postpone_id>', methods=['GET','POST'])
def complete_postpone_home(postpone_id):
         if session['user']:
                        user_id=session['user']
                        utente = User.query.filter_by(id=user_id).first()
                        utente.medaglie=utente.medaglie+1
                        utente.postpone_completati=utente.postpone_completati+1
                        PostPone.query.filter_by(id=postpone_id).delete()  #search the postpone and deletes it
                        db.session.commit()#db commit
                        return redirect(url_for('home')) #redirects to home



    #this route is used to complete a PostPone
@app.route('/complete_postpone/<postpone_id>', methods=['GET','POST'])
def complete_postpone(postpone_id):
        if session['user']:
                user_id=session['user']
                utente = User.query.filter_by(id=user_id).first()
                utente.medaglie=utente.medaglie+1   #gives a medal to the user
                utente.postpone_completati=utente.postpone_completati+1
                PostPone.query.filter_by(id=postpone_id).delete()  #search the postpone and deletes it
                db.session.commit()#db commit
        return redirect(url_for('todo')) #redirects to todo route



    #this route is used to order PostPone
@app.route('/todo_order', methods=['GET', 'POST'])
def todo_order():
    msg=''
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        number=PostPone.query.filter_by(fkey=user_id).count()
        if number==0:   #if there aren't postpone the system will show a message
            msg='Non ci sono PostPone.'
            return render_template('todo.html',utente=utente,msg=msg)
        else:
            if form['order']=='Data':                        #if the user want to order by date
                pp = PostPone.query.filter_by(fkey=user_id).order_by(PostPone.date)
                return render_template('todo.html',utente=utente,pp=pp,msg=msg)
            if form['order']=='Titolo':                      #if the user want to order by title
                pp = PostPone.query.filter_by(fkey=user_id).order_by(PostPone.title)
                return render_template('todo.html',utente=utente,pp=pp,msg=msg)
            if form['order']=='Categoria':                   #if the user want to order by category
                pp = PostPone.query.filter_by(fkey=user_id).order_by(PostPone.category)
                return render_template('todo.html',utente=utente,pp=pp,msg=msg)



    #this route is used to filter PostPone
@app.route('/todo_filter', methods=['GET', 'POST'])
def todo_filter():
             msg=''
             form=request.form
             user_id = None
             if session['user']:
                 user_id=session['user']
                 utente = User.query.filter_by(id=user_id).first()
                 number=PostPone.query.filter_by(fkey=user_id).count()
                 if number==0:  #if there aren't postpone the system will show a message
                     msg='Non ci sono PostPone.'
                     return render_template('todo.html',utente=utente,msg=msg)
                 else:
                     if form['filtro']=='Tutti':     #if the user want to show all postpone
                            return redirect(url_for('todo'))
                     if form['filtro']=='Studio':    #if the user want to show study postpone
                        number=PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Studio').count()
                        if number==0:
                             msg='Non ci sono PostPone relativi allo studio.'
                        pp = PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Studio')
                        return render_template('todo.html',utente=utente,pp=pp,msg=msg)
                     if form['filtro']=='Esame':        #if the user want to show exam postpone
                        number=PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Esame').count()
                        if number==0:   #if there are not exam postpone
                             msg='Non ci sono PostPone relativi ad esami.'
                        pp = PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Esame')
                        return render_template('todo.html',utente=utente,pp=pp,msg=msg)
                     if form['filtro']=='Ricevimento':      #if the user want to show receiving postpone
                        number=PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Ricevimento').count()
                        if number==0:#if there are not receiving postpone
                             msg='Non ci sono PostPone relativi a ricevimenti.'
                        pp = PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Ricevimento')
                        return render_template('todo.html',utente=utente,pp=pp,msg=msg)
                     if form['filtro']=='Personale':    #if the user want to show personal postpone
                        number=PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Personale').count()
                        if number==0:#if there are not personal postpone
                              msg='Non ci sono PostPone relativi ad impegni personali.'
                        pp = PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Personale')
                        return render_template('todo.html',utente=utente,pp=pp,msg=msg)
                     if form['filtro']=='Altro':    #if the user want to show other postpone
                        number=PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Altro').count()
                        if number==0:#if there are not other postpone
                              msg='Non ci sono PostPone relativi ad altri impegni.'
                        pp = PostPone.query.filter_by(fkey=user_id).filter(PostPone.category == 'Altro')
                        return render_template('todo.html',utente=utente,pp=pp,msg=msg)





    #this route redirects to the 'ricompense' page, if the user is logged
@app.route('/ricompense', methods=['GET', 'POST'])
def ricompense():
    session.pop('coupon', None) #session.pop is used to delete the temporany coupon genereted for the user
    user_id = None
    if session['user']: #if the user is logged in, he will be redirected to the page 'ricompense'
            user_id=session['user']
            utente = User.query.filter_by(id=user_id)
            return render_template('ricompense.html',utente=utente)



    #this route is used to get a coupon
@app.route('/get_coupon/<int:value>/<int:type>/', methods=['GET','POST'])#in input we have the value and the type of the selected coupon
def get_coupon(value,type):
        if session['user']:
                user_id=session['user']
                utente = User.query.filter_by(id=user_id).first()
                if utente.medaglie < value: #the system checks if the user has enough medals to unlock the coupon
                    msg='Non hai abbastanza medaglie per questa ricompensa. Completa più obiettivi!' #if the user has not enough medals he will be redirected to the same page with a message
                    utente = User.query.filter_by(id=user_id)
                    return redirect(url_for('ricompense2',msg=msg))
                else:   #if the user has enough medals he will be redirected coupon page
                    utente.medaglie=utente.medaglie-value   #removing user medals
                    utente.coupon_ottenuti=utente.coupon_ottenuti+1   #increment coupon counter
                    db.session.commit() #db commit
                    msg='Ricompensa sbloccata!'
                    utente = User.query.filter_by(id=user_id)
                    if 'coupon' not in session: #creating a coupon
                           session['coupon'] = ''.join(random.choice(chars) for _ in range(7))  #this line generates a tandom string of 7 characters
                           coupon = session['coupon']
                    else:
                        coupon='Coupon scaduto'
                        #based on the type, each coupon will be different(percentuale e marca)
                    if type==1:
                        percentuale='15%'
                        marca='Levis'
                    elif type==2:
                        percentuale='20%'
                        marca='Adidas'
                    elif type==3:
                        percentuale='25%'
                        marca='Nike'
                    elif type==4:
                        percentuale='15%'
                        marca='Napapijri'
                    elif type==5:
                        percentuale='20%'
                        marca='Amazon'
                    elif type==6:
                        percentuale='10%'
                        marca='Gucci'
                    elif type==7:
                        percentuale='15%'
                        marca='Louis Vuitton'
                    elif type==8:
                        percentuale='10%'
                        marca='Prada'
                    elif type==9:
                        percentuale='5%'
                        marca='Giorgio Armani'
                    elif type==10:
                        percentuale='7%'
                        marca='Hermes'
                    elif type==11:
                        percentuale='10%'
                        marca='Apple'
                    elif type==12:
                        percentuale='10%'
                        marca='Disney'
                    elif type==13:
                        percentuale='12%'
                        marca='HP'
                    elif type==14:
                        percentuale='15%'
                        marca='Gillette'
                    elif type==15:
                        percentuale='30%'
                        marca='H&M'
                    elif type==16:
                        percentuale='5%'
                        marca='Ebay'
                    elif type==17:
                        percentuale='10%'
                        marca='Canon'
                    elif type==18:
                        percentuale='10%'
                        marca='Loréal'
                    elif type==19:
                        percentuale='10%'
                        marca='Sony'
                    elif type==20:
                        percentuale='30%'
                        marca='Nintendo'
                    return redirect(url_for('view_coupon',percentuale=percentuale,marca=marca,coupon=coupon))



    #this route is used to view a coupon
@app.route('/view_coupon/<string:percentuale>/<string:marca>/<string:coupon>', methods=['GET','POST'])
def view_coupon(percentuale,marca,coupon):
       return render_template('coupon_page.html',coupon=coupon,percentuale=percentuale,marca=marca)


      #if a user has not enough medals, he will be redirected there, the 'ricompense' page with a message
@app.route('/ricompense2/<msg>', methods=['GET', 'POST'])
def ricompense2(msg):
    user_id = None
    if session['user']:
            user_id=session['user']
            utente = User.query.filter_by(id=user_id)
            return render_template('ricompense.html',utente=utente,msg=msg)

