/*
Checking for the existence of a user in the database
 */

const checkIfUserExists = () => {
    const registrationForm = document.forms['registration-form'] //Check on "email" form in "registration-form"
    const emailFormElement = registrationForm['email-address'] //email string
    const email = emailFormElement.value
    axios.post('/validate-user', {
        email: email
    })
        .then((response) => {
            if(response.data.user_exists == "true") {
              //if already exists:
                emailFormElement.setCustomValidity('Esiste già un account con questa mail associata. Per favore cambia indirizzo.')
                emailFormElement.reportValidity()
            }
//Error generation
        }, (error) => {
            console.log(error)
        })
}

