
const quizData = [
    {

        question: "La scelta di livelli passivi e negativi per le caratteristiche elettriche dello standard RS232 è stata fatta",
        a: "Perché costa meno rispetto a segnali di eguale polarità",
        b: "Per favorire le trasmissioni e consentire cavi di collegamento più lunghi",
        c: "Per uniformità con i livelli logici all'interno dei computer",
        d: "Per poter usare amplificatori differenziali nei driver di uscita",
        correct: "b",
    },
    {
        question: "Il tradizionale modello di gestione delle telecomunicazioni con un gestore dominantemonopolista legato al capitale pubblico: ",
        a: "E'stato un fenomeno esclusivamente italiano",
        b: "Si è applicato a tutti i paesi d'europa",
        c: "E' stato un fenomeno tipico degli USA",
        d: "Non si è mai applicato alla Francia",
        correct: "b",
    },
    {
        question: "Il termine best effort usato per la rete Internet: ",
        a: "Indica che Internet e' la rete che offre la qualita' di servizio migliore",
        b: "Indica che la rete fa del suo meglio per consegnare i pacchetti ma non garantisce alcun livello diservizio",
        c: "Indica che l'utente puo' chiedere alla rete servizi diversi e migliori",
        d: "Indica che Internet e' stata progettata cercando di renderla migliore possibile dal punto di vistaeconomico",
        correct: "d",
    },
    {
        question: "La velocita' base della gerarchia SDH vale:",
        a: "Circa 2 Mbit/s",
        b: "Circa 34 Mbit/s",
        c: "Circa 100 Mbit/s",
        d: "Circa 155 Mbit/s",
        correct: "d",
    },
];

const quiz = document.getElementById('quiz')
const answerEls = document.querySelectorAll('.answer')
const questionEl = document.getElementById('question')
const a_text = document.getElementById('a_text')
const b_text = document.getElementById('b_text')
const c_text = document.getElementById('c_text')
const d_text = document.getElementById('d_text')
const submitBtn = document.getElementById('submit')

let currentQuiz = 0
let score = 0

loadQuiz()

function loadQuiz() {
    deselectAnswers()

    const currentQuizData = quizData[currentQuiz]

    questionEl.innerText = currentQuizData.question
    a_text.innerText = currentQuizData.a
    b_text.innerText = currentQuizData.b
    c_text.innerText = currentQuizData.c
    d_text.innerText = currentQuizData.d
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false)
}

function getSelected() {
    let answer

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id
        }
    })

    return answer
}

submitBtn.addEventListener('click', () => {
    const answer = getSelected()

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++
        }

        currentQuiz++

        if(currentQuiz < quizData.length) {
            loadQuiz()
        } else {
            if(score==4) {
                quiz.innerHTML = `
                <h2>Hai risposto a ${score}/${quizData.length} domande correttamente</h2>
                `
                document.getElementById("getmedal").style.display="initial";
            }else { quiz.innerHTML = `
                <h2>Hai risposto a ${score}/${quizData.length} domande correttamente</h2>

                <button onclick="location.reload()">Riprova</button>
                
                
            `}
        }


    }
})
