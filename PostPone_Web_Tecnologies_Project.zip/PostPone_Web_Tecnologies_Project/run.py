# run.py

#from package app import object app
from app import app

#it Allows to Execute Code When the File Runs as a Script
if __name__ == '__main__':
    app.run()