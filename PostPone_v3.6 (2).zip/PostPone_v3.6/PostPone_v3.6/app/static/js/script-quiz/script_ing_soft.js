
const quizData = [
    {

        question: "In quale fase di sviluppo di un progetto software verrà prevalentemente impiegato un programmatore ?",
        a: "Pianificazione",
        b: "Progettazione",
        c: "Sviluppo e implementazione",
        d: "Analisi dei requisiti",
        correct: "c",
    },
    {
        question: "Cosa viene eseguito durante la fase di analisi dei requisiti?",
        a: "Vengono approvate tutte le richieste del cliente\n",
        b: "Viene costruito un prototipo",
        c: "Viene eseguita un'analisi del vecchio sistema e si intervista il cliente sulle caratteristiche del nuovo sistema che desidera",
        d: "Si allocano le risorse necessarie al progetto",
        correct: "c",
    },
    {
        question: "Quale è l'ordine corretto delle fasi nel caso di modello a cascata?",
        a: "Manutenzione, Studio di fattibilità, Integrazione, Progettazione, Analisi dei requisiti, Sviluppo",
        b: "Studio di Fattibilità, Analisi dei requisiti, Sviluppo, Progettazione, Integrazione, Manutenzione",
        c: "Studio di Fattibilità, Analisi dei requisiti, Progettazione, Sviluppo, Integrazione, Manutenzione",
        d: "Analisi dei requisiti, Studio di Fattibilità, Progettazione, Sviluppo, Integrazione, Manutenzione",
        correct: "c",
    },
    {
        question: "Nei sistemi incrementali:",
        a: "L'analisi dei requisiti prosegue ed evolve con il cliente durante l'intero sviluppo del progetto",
        b: "L'analisi dei requisiti viene congelata durante la prima fase del progetto",
        c: "Il cliente vede il progetto solo quando è terminato",
        d: "Da subito sono presenti tutte le funzionalità che verranno raffinate successivamente",
        correct: "a",
    },
];

const quiz = document.getElementById('quiz')
const answerEls = document.querySelectorAll('.answer')
const questionEl = document.getElementById('question')
const a_text = document.getElementById('a_text')
const b_text = document.getElementById('b_text')
const c_text = document.getElementById('c_text')
const d_text = document.getElementById('d_text')
const submitBtn = document.getElementById('submit')

let currentQuiz = 0
let score = 0

loadQuiz()

function loadQuiz() {
    deselectAnswers()

    const currentQuizData = quizData[currentQuiz]

    questionEl.innerText = currentQuizData.question
    a_text.innerText = currentQuizData.a
    b_text.innerText = currentQuizData.b
    c_text.innerText = currentQuizData.c
    d_text.innerText = currentQuizData.d
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false)
}

function getSelected() {
    let answer

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id
        }
    })

    return answer
}

submitBtn.addEventListener('click', () => {
    const answer = getSelected()

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++
        }

        currentQuiz++

        if(currentQuiz < quizData.length) {
            loadQuiz()
        } else {
            quiz.innerHTML = `
                <h2>Hai risposto a ${score}/${quizData.length} domande correttamente</h2>

                <button onclick="location.reload()">Riprova</button>
            `
        }
    }
})
