
const quizData = [
    {

        question: "Quale tag usiamo per inserire un paragrafo?",
        a: "<title></title>",
        b: "<html></html>",
        c: "<p></p>",
        d: "<h1></h1>",
        correct: "c",
    },
    {
        question: "In CSS come si può definire l'altezza di tutte le immagini?",
        a: "img[height:100px]",
        b: "img{height:100px}",
        c: ".img{height:100px}",
        d: "#img{height:100px}",
        correct: "b",
    },
    {
        question: "Quale delle seguenti opzioni esprime la struttura di un tag?",
        a: "<tag attributo=\"valore attributo\"></tag>",
        b: "<tag =\"valore attributo\"></tag>",
        c: "<tag attributo></tag>",
        d: "<tag attributo=\"valore attributo\"><tag>",
        correct: "a",
    },
    {
        question: "Quale attributo in combinazione al tag <a> ci permette di inserire l'indirizzo (link) di destinazione?",
        a: "link",
        b: "href",
        c: "height",
        d: "rel",
        correct: "b",
    },
];

const quiz = document.getElementById('quiz')
const answerEls = document.querySelectorAll('.answer')
const questionEl = document.getElementById('question')
const a_text = document.getElementById('a_text')
const b_text = document.getElementById('b_text')
const c_text = document.getElementById('c_text')
const d_text = document.getElementById('d_text')
const submitBtn = document.getElementById('submit')

let currentQuiz = 0
let score = 0

loadQuiz()

function loadQuiz() {
    deselectAnswers()

    const currentQuizData = quizData[currentQuiz]

    questionEl.innerText = currentQuizData.question
    a_text.innerText = currentQuizData.a
    b_text.innerText = currentQuizData.b
    c_text.innerText = currentQuizData.c
    d_text.innerText = currentQuizData.d
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false)
}

function getSelected() {
    let answer

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id
        }
    })

    return answer
}

submitBtn.addEventListener('click', () => {
    const answer = getSelected()

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++
        }

        currentQuiz++

        if(currentQuiz < quizData.length) {
            loadQuiz()
        } else {
            quiz.innerHTML = `
                <h2>Hai risposto a ${score}/${quizData.length} domande correttamente</h2>

                <button onclick="location.reload()">Riprova</button>
            `
        }
    }
})
