
const quizData = [
    {

        question: "L'unità di misura del vettore densità di corrente è:",
        a: "Ampere metro",
        b: "Coulomb metro",
        c: "Coulomb/(sec metro2)",
        d: "Coulomb/sec",
        correct: "c",
    },
    {
        question: "La legge di Ohm: ",
        a: "Lega il campo E alla densità J",
        b: "Descrive il legame tra tensione e corrente in un resistore",
        c: "E' una delle leggi di Kirchhoff",
        d: "E' sempre valida",
        correct: "b",
    },
    {
        question: "La forza Coulombiana: ",
        a: "Diminuisce linearmente con l'aumentare della distanza tra le cariche",
        b: "Non è sovrapponibile",
        c: "Regola l'interazione tra le correnti",
        d: "Diminuisce con l'inverso del quadrato della distanza",
        correct: "d",
    },
    {
        question: "Una rete si dice piana quando:",
        a: "Quando è possibile disegnare il suo grafo in un piano sensa \"accavallamenti\" dei rami",
        b: "Quando ha una struttura semplice",
        c: "Quando il numero dei nodi è uguale a quello dei rami",
        d: "Quando è disegnata in un piano",
        correct: "c",
    },
];

const quiz = document.getElementById('quiz')
const answerEls = document.querySelectorAll('.answer')
const questionEl = document.getElementById('question')
const a_text = document.getElementById('a_text')
const b_text = document.getElementById('b_text')
const c_text = document.getElementById('c_text')
const d_text = document.getElementById('d_text')
const submitBtn = document.getElementById('submit')

let currentQuiz = 0
let score = 0

loadQuiz()

function loadQuiz() {
    deselectAnswers()

    const currentQuizData = quizData[currentQuiz]

    questionEl.innerText = currentQuizData.question
    a_text.innerText = currentQuizData.a
    b_text.innerText = currentQuizData.b
    c_text.innerText = currentQuizData.c
    d_text.innerText = currentQuizData.d
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false)
}

function getSelected() {
    let answer

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id
        }
    })

    return answer
}

submitBtn.addEventListener('click', () => {
    const answer = getSelected()

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++
        }

        currentQuiz++

        if(currentQuiz < quizData.length) {
            loadQuiz()
        } else {
            quiz.innerHTML = `
                <h2>Hai risposto a ${score}/${quizData.length} domande correttamente</h2>

                <button onclick="location.reload()">Riprova</button>
            `
        }
    }
})
