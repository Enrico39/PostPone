from werkzeug.utils import redirect
from app import app, db
from app.models import User
from flask import json, render_template, request, session, url_for, jsonify, flash


import os
msg=''
@app.route('/')
def index():
    if 'user' in session.keys():
        return redirect(url_for('home'))
    else:
        return render_template('main.html')



@app.route('/home')
def home():
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id)
        return render_template('home.html',utente=utente)




@app.route('/chisiamo', methods=['GET', 'POST'])
def chisiamo():
    return render_template('chisiamo.html')

@app.route('/ricompense', methods=['GET', 'POST'])
def ricompense():
    return render_template('ricompense.html')

@app.route('/profilo', methods=['GET', 'POST'])
def profilo():
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id)
        return render_template('mioprofilo.html',utente=utente,msg=msg)

@app.route('/pomodoroclock', methods=['GET', 'POST'])
def pomodoroclock():
    return render_template('pomodoroclock.html')

@app.route('/triviaquiz', methods=['GET', 'POST'])
def triviaquiz():
    return render_template('quizindex.html')

@app.route('/register-user', methods=['POST'])
def register_user():
    form = request.form
    user = User(
        username=form['username'],
        name=form['name'],
        surname=form['surname'],
        email=form['email-address'])
    user.set_password(form['password'])
    db.session.add(user)
    db.session.commit()
    return redirect(url_for('index'))

@app.route('/validate-user', methods=['POST'])
def validate_user():
    if request.method == "POST":
        email_address = request.get_json()['email']
        user = User.query.filter_by(email=email_address).first()
        if user:
            return jsonify({'user_exists': 'true'})
        else:
            return jsonify({'user_exists': 'false'})

@app.route('/validate-password', methods=['POST'])
def validate_password():
    if request.method == "POST":
        email_address = request.get_json()['email']
        password = request.get_json()['password']
        userFound = 'false'
        passwordCorrect = 'false'
        user = User.query.filter_by(email=email_address).first()
        if user:
            userFound = 'true'
            if user.check_password(password):
                passwordCorrect = 'true'

        return jsonify({'user_exists': userFound, 'passwordCorrect': passwordCorrect})

@app.route('/login-user', methods=['POST'])
def login_user():
    msg=""
    form = request.form
    user = User.query.filter_by(email=form['email-address']).first()

    if not user:
        msg = "email non trovata nel sistema, registrati!"
        return render_template('main.html', form=form,msg=msg)

    if user and user.check_password(form['password']):
        # if not, redirect to index and give flask message (don't worry about javascript validation)
        session['user'] = user.id
        #flash("Accesso eseguito con successo!","info")
        return redirect(url_for('home'))
    else:

        msg = "Username o password sbagliati, riprova!"
        #flash("Password was incorrect or user doesn't exist.")
        #return redirect(url_for('index'))
        return render_template('main.html', form=form,msg=msg)




@app.route('/logout-user', methods=['POST', 'GET'])
def logout_user():
    session.pop('user', None)
    return redirect(url_for('index'))



@app.route('/info', methods=['GET', 'POST'])
def info():
    return render_template('templates_quiz/quizinformatica.html')


@app.route('/bio', methods=['GET', 'POST'])
def bio():
    return render_template('templates_quiz/index_bio.html')




@app.route('/nav', methods=['GET', 'POST'])
def nav():
    return render_template('templates_quiz/index_nav.html')

@app.route('/eco', methods=['GET', 'POST'])
def eco():
    return render_template('templates_quiz/index_eco.html')


@app.route('/giu', methods=['GET', 'POST'])
def giu():
    return render_template('templates_quiz/index_giur.html')


@app.route('/tel', methods=['GET', 'POST'])
def tel():
    return render_template('templates_quiz/index_telec.html')


@app.route('/soc', methods=['GET', 'POST'])
def soc():
    return render_template('templates_quiz/index_sociol.html')


@app.route('/ing', methods=['GET', 'POST'])
def ing():
    return render_template('templates_quiz/index_ing_gest.html')


@app.route('/reti', methods=['GET', 'POST'])
def reti():
    return render_template('templates_quiz/index_reti.html')

@app.route('/ingsw', methods=['GET', 'POST'])
def ingsw():
    return render_template('templates_quiz/index_ing_soft.html')

@app.route('/prog3', methods=['GET', 'POST'])
def prog3():
    return render_template('templates_quiz/index_prog3.html')

@app.route('/so', methods=['GET', 'POST'])
def so():
    return render_template('templates_quiz/index_SO.html')

@app.route('/tw', methods=['GET', 'POST'])
def tw():
    return render_template('templates_quiz/index_tech_web.html')






@app.route('/change_uni', methods=['POST'])
def change_uni():
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        utente.uni=form['uni']


        db.session.commit()
        return redirect(url_for('profilo'))




@app.route('/change_cds', methods=['POST'])
def change_cds():
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        utente.cds=form['cds']


        db.session.commit()
        return redirect(url_for('profilo'))




@app.route('/change_cell', methods=['POST'])
def change_cell():
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        utente.cell=form['cell']

        db.session.commit()
        return redirect(url_for('profilo'))




@app.route('/change_eta', methods=['POST'])
def change_eta():
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        utente.eta=form['eta']

        db.session.commit()
        return redirect(url_for('profilo'))



@app.route('/change_password', methods=['POST'])
def change_password():
    msg=''
    form=request.form
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        if utente.check_password(form['old_password']):
            if form['new_password']==form['confirm_password']:
                if form['new_password']=='':
                    msg='Compila i campi!'
                    utente = User.query.filter_by(id=user_id)
                    return render_template('mioprofilo.html',utente=utente,msg=msg)
                else:
                    utente.set_password(form['new_password'])
                    db.session.commit()
                    msg='Cambio password effettuato con successo!'
                    utente = User.query.filter_by(id=user_id)
                    return render_template('mioprofilo.html',utente=utente,msg=msg)
            else:
                msg='Password non corrispondenti'
                utente = User.query.filter_by(id=user_id)
                return render_template('mioprofilo.html',utente=utente,msg=msg)
        else:
            msg='Vecchia password errata'
            utente = User.query.filter_by(id=user_id)
            return render_template('mioprofilo.html',utente=utente,msg=msg)




@app.route('/delete_account', methods=['POST'])
def delete_account():
    user_id = None
    if session['user']:
        user_id=session['user']
        utente = User.query.filter_by(id=user_id).first()
        db.session.delete(utente)
        db.session.commit()
        msg='Account eliminato correttamente.'
        return render_template('main.html',msg=msg)
