from werkzeug.utils import redirect
from app import app, db
from app.models import User
from flask import json, render_template, request, session, url_for, jsonify, flash


import os

@app.route('/')
def index():
    if 'user' in session.keys():
        return redirect(url_for('home'))
    else:
        return render_template('main.html')



@app.route('/home')
def home():
        return render_template('home.html')




@app.route('/chisiamo', methods=['GET', 'POST'])
def chisiamo():
    return render_template('chisiamo.html')

@app.route('/pomodoroclock', methods=['GET', 'POST'])
def pomodoroclock():
    return render_template('pomodoroclock.html')

@app.route('/triviaquiz', methods=['GET', 'POST'])
def triviaquiz():
    return render_template('quizindex.html')

@app.route('/register-user', methods=['POST'])
def register_user():
    form = request.form
    user = User(
        username=form['username'],
        name=form['name'],
        surname=form['surname'],
        email=form['email-address'])
    user.set_password(form['password'])
    db.session.add(user)
    db.session.commit()
    return redirect(url_for('index'))

@app.route('/validate-user', methods=['POST'])
def validate_user():
    if request.method == "POST":
        email_address = request.get_json()['email']
        user = User.query.filter_by(email=email_address).first()
        if user:
            return jsonify({'user_exists': 'true'})
        else:
            return jsonify({'user_exists': 'false'})

@app.route('/validate-password', methods=['POST'])
def validate_password():
    if request.method == "POST":
        email_address = request.get_json()['email']
        password = request.get_json()['password']
        userFound = 'false'
        passwordCorrect = 'false'
        user = User.query.filter_by(email=email_address).first()
        if user:
            userFound = 'true'
            if user.check_password(password):
                passwordCorrect = 'true'

        return jsonify({'user_exists': userFound, 'passwordCorrect': passwordCorrect})

@app.route('/login-user', methods=['POST'])
def login_user():
    msg=""
    form = request.form
    user = User.query.filter_by(email=form['email-address']).first()

    if not user:
        msg = "email non trovata nel sistema, registrati!"
        return render_template('main.html', form=form,msg=msg)

    if user and user.check_password(form['password']):
        # if not, redirect to index and give flask message (don't worry about javascript validation)
        session['user'] = user.id
        #flash("Accesso eseguito con successo!","info")
        return redirect(url_for('home'))
    else:

        msg = "Username o password sbagliati, riprova!"
        #flash("Password was incorrect or user doesn't exist.")
        #return redirect(url_for('index'))
        return render_template('main.html', form=form,msg=msg)




@app.route('/logout-user', methods=['POST', 'GET'])
def logout_user():
    session.pop('user', None)
    return redirect(url_for('index'))









@app.route('/patients', methods=['POST', 'GET'])
def patients():
    doctor = None
    if session['doctor']:
        doctor = session['doctor']
        patients = Patient.query.filter_by(doctor_id=doctor)
        return render_template('patients.html', patients=patients)
    return render_template('patients.html')


