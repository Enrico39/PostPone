# To-do list App, built with jQuery v1.1.2 ⭐

A Pen created on CodePen.io. Original URL: [https://codepen.io/tns301/pen/mmpMQN](https://codepen.io/tns301/pen/mmpMQN).

A simple To-do list built with jQuery.

Update v1.1
- Optimizations
-  Added a function to update text.

Update v1.1.1
-  Minor fixes and simplified some functions.

Update v1.1.2
-  New opening animations for tasks.

*featured on the front-page.