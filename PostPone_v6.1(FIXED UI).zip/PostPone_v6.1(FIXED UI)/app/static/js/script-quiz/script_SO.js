
const quizData = [
    {

        question: "Cosa si intende per sistema operativo?",
        a: "Un insieme di programmi che gestisce tutte le risorse HW e SW del computer",
        b: "Un dispositivo HW per il controllo delle risorse",
        c: "Un programma per interagire con il computer",
        d: "Il sistema operativo viene aggiunto al computer che potrebbe funzionare anche senza",
        correct: "a",
    },
    {
        question: "Quando un sistema operativo si dice portabile? ",
        a: "Quando è multiprogrammato",
        b: "Quando può funzionare su hardware differenti",
        c: "Quando può funzionare su Software differenti",
        d: "Quando è inj modalità testuale",
        correct: "b",
    },
    {
        question: "Cosa si intende per processo?",
        a: "Un'entità concreta e statica",
        b: "Viene generato quando si lancia l'esecuzione di un programma",
        c: "E' il codice associato al programma",
        d: "E' il programma che si trova sull'hard disk",
        correct: "b",
    },
    {
        question: "Un interrupt: ",
        a: "E' un segnale gestito dalla memoria RAM",
        b: "E' un segnale che viene gestito dalla tastiera quando si verifica un interruzione di corrente",
        c: "E' un segnale inviato alla CPU se si verifica un evento anomalo",
        d: "è un segnale che viene inviato alla memoria di massa",
        correct: "c",
    },
];

const quiz = document.getElementById('quiz')
const answerEls = document.querySelectorAll('.answer')
const questionEl = document.getElementById('question')
const a_text = document.getElementById('a_text')
const b_text = document.getElementById('b_text')
const c_text = document.getElementById('c_text')
const d_text = document.getElementById('d_text')
const submitBtn = document.getElementById('submit')

let currentQuiz = 0
let score = 0

loadQuiz()

function loadQuiz() {
    deselectAnswers()

    const currentQuizData = quizData[currentQuiz]

    questionEl.innerText = currentQuizData.question
    a_text.innerText = currentQuizData.a
    b_text.innerText = currentQuizData.b
    c_text.innerText = currentQuizData.c
    d_text.innerText = currentQuizData.d
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false)
}

function getSelected() {
    let answer

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id
        }
    })

    return answer
}

submitBtn.addEventListener('click', () => {
    const answer = getSelected()

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++
        }

        currentQuiz++

        if(currentQuiz < quizData.length) {
            loadQuiz()
        } else {
            if(score==4) {
                quiz.innerHTML = `
                <h2>Hai risposto a ${score}/${quizData.length} domande correttamente</h2>
                `
                document.getElementById("getmedal").style.display="initial";
            }else { quiz.innerHTML = `
                <h2>Hai risposto a ${score}/${quizData.length} domande correttamente</h2>

                <button onclick="location.reload()">Riprova</button>
                
                
            `}
        }


    }
})
