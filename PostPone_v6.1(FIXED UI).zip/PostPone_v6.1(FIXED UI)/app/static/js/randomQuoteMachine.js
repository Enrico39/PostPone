window.onload = go;
function go() {
  // Triggers genRandQuote when New Quote button is clicked
  $("#new-quote").click(function() {
    genRandQuote();
  });

  // Generate a random quote when window is loaded initially
  genRandQuote();
}

// Generates a random quote from the quote variable and renders it to DOM
function genRandQuote() {
  var quotes = [{
		id: 1,
		text: "Ogni volta che impariamo qualcosa di nuovo, noi stessi diventiamo qualcosa di nuovo.",
		source: "- Leo Buscaglia"
	},
	{
		id: 2,
		text: "Lo studio e, in generale, la ricerca della verità e della bellezza sono una sfera di attività nella quale ci è consentito di rimanere bambini per tutta la vita.",
		source: "- Albert Einstein"
	},
	{
		id: 3,
		text: "Nessuna giornata in cui si è imparato qualcosa è andata persa.",
		source: "- David Eddings"
	},
	{
		id: 4,
		text: "Studiare è questo. Improvvisamente si comprende qualcosa che si era capita da tutta una vita, ma da un nuovo punto di vista.",
		source: "- Doris May Lessing"
	},
	{
		id: 5,
		text: "Metti in dubbio ogni piccola cosa.",
		source: "- J. Dorsey"
	},
	{
		id: 6,
		text: "Il miglior investimento è un libro.",
		source: "- R. Holiday"
	},
	{
		id: 7,
		text: "Chi non legge a 70 anni avrà vissuto una sola vita. Chi legge avrà vissuto 5000 anni.",
		source: "- U. Eco"
	},
	{
		id: 8,
		text: "Non percorrere mai la strada più semplice perché ti porterà dove sono già stati altri." ,
		source: "- Graham Bell"
	},
	{
		id: 9,
		text: "Si è uno studente finché si ha ancora qualcosa da imparare, e questo significa per tutta la vita.",
		source: "– Henry L. Doherty"
	},
	  {
		  id: 10,
		  text: "La cultura non occupa spazio.",
		  source: ""
	  },
];
  var randQuote = quotes[Math.floor(Math.random() * (quotes.length))];
  $("#text").html(randQuote.text);
  $("#author").html(randQuote.source);
}
