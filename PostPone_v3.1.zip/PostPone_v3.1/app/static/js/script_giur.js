
const quizData = [
    {

        question: "Che cosa è il Patto europlus?",
        a: "E' un programma principale, sottoscritto nel 2015, che interessa due settori: competitività e occupazione",
        b: "E' un programma principale, sottoscritto nel 2014, che interessa quattro settori: competitività; occupazione; sostenibilità delle finanze pubbliche; maggiore stabilità  finanziaria",
        c: "E' un programma complementare, sottoscritto nel 2012, che interessa tre settori: competitività; occupazione e sostenibilità delle finanze pubbliche; maggiore stabilità  finanziaria",
        d: "E' un programma complementare, sottoscritto nel 2011, che interessa quattro settori: competitività; occupa-zione; sostenibilità delle finanze pubbliche; maggiore stabilità  finanziaria",
        correct: "d",
    },
    {
        question: "Individuare l'effetto principale dell'integrazione europea vuol dire: ",
        a: "Elevazione degli strumenti della protezione dei diritti e della tutelagiurisdizionale",
        b: "Riduzione delle fluttuazioni di mercato",
        c: "Attenuazione del meccanismo di protezione dei mercati",
        d: "Eliminazione di ogni forma di discriminazione razziale",
        correct: "a",
    },
    {
        question: "Che cosa assicurano i Regolamenti relativi al two pack? ",
        a: "Eliminano le barriere all'entrata nel mercato  ",
        b: "Riducono la stabilità finanziaria",
        c: "Eliminano ogni forma di sorveglianza economica e di bilancio degli Stati membri",
        d: "Assicurano la trasparenza delle decisioni dibilancio",
        correct: "d",
    },
    {
        question: "Individuare  l'obiettivo del Patto di stabilità e crescita vuol dire:",
        a: "Limitare gli interventi discrezionali di politica fiscale alla riduzione dell'indebitamento, evitando l'adozione di manovre anticicliche",
        b: "Consentire il funzionamento delle variabili",
        c: "Dotare i Paesi dell'UE di un codice dei contratti per una gestione disciplinata dei mercati  ",
        d: "Garantire i Paesi dell'UE da manovre anticiriciclaggio",
        correct: "a",
    },
];

const quiz = document.getElementById('quiz')
const answerEls = document.querySelectorAll('.answer')
const questionEl = document.getElementById('question')
const a_text = document.getElementById('a_text')
const b_text = document.getElementById('b_text')
const c_text = document.getElementById('c_text')
const d_text = document.getElementById('d_text')
const submitBtn = document.getElementById('submit')

let currentQuiz = 0
let score = 0

loadQuiz()

function loadQuiz() {
    deselectAnswers()

    const currentQuizData = quizData[currentQuiz]

    questionEl.innerText = currentQuizData.question
    a_text.innerText = currentQuizData.a
    b_text.innerText = currentQuizData.b
    c_text.innerText = currentQuizData.c
    d_text.innerText = currentQuizData.d
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false)
}

function getSelected() {
    let answer

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id
        }
    })

    return answer
}

submitBtn.addEventListener('click', () => {
    const answer = getSelected()

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++
        }

        currentQuiz++

        if(currentQuiz < quizData.length) {
            loadQuiz()
        } else {
            quiz.innerHTML = `
                <h2>Hai risposto a ${score}/${quizData.length} domande correttamente</h2>

                <button onclick="location.reload()">Riprova</button>
            `
        }
    }
})
