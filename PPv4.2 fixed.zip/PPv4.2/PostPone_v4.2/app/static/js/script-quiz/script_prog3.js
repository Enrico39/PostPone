
const quizData = [
    {

        question: "Quali di queste dichiarazioni corrisponde alla corretta dichiarazione del metodo main?",
        a: "public static void main(String args)",
        b: "public void main(String args)",
        c: "public static void main(String args[])",
        d: "public static void main()",
        correct: "c",
    },
    {
        question: "Qual è la forma della dichiarazione di una costante di tipo carattere?",
        a: "final char r = Y;",
        b: "char final r = 'Y';",
        c: "final int r = 'Y';",
        d: "final char r ='Y';",
        correct: "d",
    },
    {
        question: "Come si può rappresentare la definizione di una classe?",
        a: "Elencando solo i suoi attributi",
        b: "Elencando solo i suoi metodi",
        c: "Elencando sia i suoi attributi che i metodi",
        d: "Facendo alcuni esempi",
        correct: "c",
    },
    {
        question: "Qual è la corretta dichiarazione per specificare cha la classe A è sottoclasse della classe B?",
        a: "class A",
        b: "class A extends B",
        c: "class B extends A",
        d: "class A extend B",
        correct: "b",
    },
];


const quiz = document.getElementById('quiz')
const answerEls = document.querySelectorAll('.answer')
const questionEl = document.getElementById('question')
const a_text = document.getElementById('a_text')
const b_text = document.getElementById('b_text')
const c_text = document.getElementById('c_text')
const d_text = document.getElementById('d_text')
const submitBtn = document.getElementById('submit')

let currentQuiz = 0
let score = 0

loadQuiz()

function loadQuiz() {
    deselectAnswers()

    const currentQuizData = quizData[currentQuiz]

    questionEl.innerText = currentQuizData.question
    a_text.innerText = currentQuizData.a
    b_text.innerText = currentQuizData.b
    c_text.innerText = currentQuizData.c
    d_text.innerText = currentQuizData.d
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false)
}

function getSelected() {
    let answer

    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id
        }
    })

    return answer
}

submitBtn.addEventListener('click', () => {
    const answer = getSelected()

    if(answer) {
        if(answer === quizData[currentQuiz].correct) {
            score++
        }

        currentQuiz++

        if(currentQuiz < quizData.length) {
            loadQuiz()
        } else {
            quiz.innerHTML = `
                <h2>Hai risposto a ${score}/${quizData.length} domande correttamente</h2>

                <button onclick="location.reload()">Riprova</button>
            `
        }
    }
})
